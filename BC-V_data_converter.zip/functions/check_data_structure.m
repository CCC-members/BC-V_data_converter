function [report,subject_name] = check_data_structure(selected_data_set,app_properties,subject_name)


    
end

